// Archivo JavaScript principal para el sitio público de Abogados Forenses
// Se puede añadir funcionalidad adicional aquí si es necesario.
console.log("main.js cargado");

